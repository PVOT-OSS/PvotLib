// SPDX-FileCopyrightText: 2026 Saalim Quadri <danascape@gmail.com>
// SPDX-License-Identifier: Apache-2.0

package com.prauga.pvot.designsystem.navigation

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * Represents a navigation tab item.
 *
 * @param iconRes Icon for collapsed state.
 * @param labelRes Label text.
 * @param contentDescriptionRes Accessibility description.
 * @param expandedIconRes Icon for expanded state (defaults to [iconRes]).
 * @param expandedLabelRes Label for expanded state (defaults to [labelRes]).
 * @param badgeCount Number shown in a badge on the icon, such as unread items; 0 hides the badge.
 */
public data class PvotTabItem(
    @DrawableRes val iconRes: Int,
    @StringRes val labelRes: Int,
    @StringRes val contentDescriptionRes: Int,
    @DrawableRes val expandedIconRes: Int? = null,
    @StringRes val expandedLabelRes: Int? = null,
    val badgeCount: Int = 0,
)
