// SPDX-FileCopyrightText: 2026 Saalim Quadri <danascape@gmail.com>
// SPDX-License-Identifier: Apache-2.0

package com.prauga.pvot.designsystem.components.picker.internal

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prauga.pvot.designsystem.R
import com.prauga.pvot.designsystem.components.picker.PvotPickerColors
import com.prauga.pvot.designsystem.components.picker.PvotPickerDefaults
import com.prauga.pvot.designsystem.theme.PvotShapes
import com.prauga.pvot.designsystem.theme.PvotSpacing
import kotlin.math.abs
import kotlinx.coroutines.launch

private val DefaultItemHeight = 40.dp
private val DefaultVisibleItems = 5
private val DefaultWheelWidth = 110.dp

// wheel effect constants
private const val MAX_ROTATION_DEGREES = 60f
private const val MIN_SCALE = 0.7f
private const val MIN_ALPHA = 0.3f

/** Wheel engine that handles scrolling, snapping, and rendering with 3D cylindrical effect. */
@Composable
internal fun WheelEngine(
    config: WheelConfig,
    onValueSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    colors: PvotPickerColors = PvotPickerDefaults.themeColors(),
    itemHeight: Dp = DefaultItemHeight,
    visibleItemsCount: Int = DefaultVisibleItems,
) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = config.initialIndex)
    val flingBehavior = rememberSnapFlingBehavior(listState)
    val hapticFeedback = LocalHapticFeedback.current
    var lastSelectedIndex by remember { mutableIntStateOf(config.initialIndex) }
    val currentConfig by rememberUpdatedState(config)
    val currentOnValueSelected by rememberUpdatedState(onValueSelected)

    val scope = rememberCoroutineScope()
    val suffix = config.suffixRes?.let { stringResource(it) }.orEmpty()
    val wheelName = config.descriptionRes?.let { stringResource(it) }.orEmpty()
    val nextLabel = stringResource(R.string.pvot_picker_action_next)
    val previousLabel = stringResource(R.string.pvot_picker_action_previous)
    val selectedLabel =
        config.values
            .getOrNull(lastSelectedIndex)
            ?.let { listOfNotNull(config.label(it), suffix.ifEmpty { null }).joinToString(" ") }
            .orEmpty()

    val density = LocalDensity.current
    val itemHeightPx = with(density) { itemHeight.toPx() }
    val halfVisibleItems = visibleItemsCount / 2f

    LaunchedEffect(config.initialIndex) {
        val target = config.initialIndex.coerceIn(config.values.indices)
        if (target != lastSelectedIndex) {
            lastSelectedIndex = target
            listState.scrollToItem(target)
        }
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .collect { index ->
                val values = currentConfig.values
                val selected = index.coerceIn(values.indices)
                if (selected != lastSelectedIndex) {
                    lastSelectedIndex = selected
                    hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    currentOnValueSelected(values[selected])
                }
            }
    }

    Box(
        modifier =
            modifier.height(itemHeight * visibleItemsCount).width(DefaultWheelWidth).semantics(
                mergeDescendants = true
            ) {
                contentDescription = wheelName
                stateDescription = selectedLabel
                customActions =
                    listOf(
                        CustomAccessibilityAction(nextLabel) {
                            val target =
                                (lastSelectedIndex + 1).coerceAtMost(config.values.lastIndex)
                            scope.launch { listState.animateScrollToItem(target) }
                            true
                        },
                        CustomAccessibilityAction(previousLabel) {
                            val target = (lastSelectedIndex - 1).coerceAtLeast(0)
                            scope.launch { listState.animateScrollToItem(target) }
                            true
                        },
                    )
            }
    ) {
        LazyColumn(
            state = listState,
            flingBehavior = flingBehavior,
            contentPadding = PaddingValues(vertical = itemHeight * (visibleItemsCount / 2)),
            modifier = Modifier.fillMaxSize().clearAndSetSemantics {},
        ) {
            items(config.values.size) { index ->
                WheelItem(
                    text = config.label(config.values[index]),
                    suffix = suffix,
                    colors = colors,
                    normalizedDistance = {
                        val distanceFromCenter =
                            (index - listState.firstVisibleItemIndex) -
                                (listState.firstVisibleItemScrollOffset / itemHeightPx)
                        (distanceFromCenter / halfVisibleItems).coerceIn(-1f, 1f)
                    },
                    modifier = Modifier.height(itemHeight),
                )
            }
        }

        // Selection indicator
        Box(
            modifier =
                Modifier.align(Alignment.Center)
                    .height(itemHeight)
                    .fillMaxWidth()
                    .background(colors.selectionBackgroundColor, PvotShapes.Selection)
        )
    }
}

/**
 * A single wheel row.
 *
 * [normalizedDistance] is read in the draw phase, so scrolling re-runs the layer block rather than
 * recomposing every visible row.
 */
@Composable
private fun WheelItem(
    text: String,
    suffix: String,
    colors: PvotPickerColors,
    normalizedDistance: () -> Float,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier =
            modifier.fillMaxWidth().graphicsLayer {
                val distance = normalizedDistance()
                val itemScale = 1f - (abs(distance) * (1f - MIN_SCALE))
                this.rotationX = distance * MAX_ROTATION_DEGREES
                this.scaleX = itemScale
                this.scaleY = itemScale
                this.alpha = 1f - (abs(distance) * (1f - MIN_ALPHA))
                this.transformOrigin = TransformOrigin.Center
                this.cameraDistance = 12f * density
            },
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(text = text, fontSize = 28.sp, color = colors.textColor)
            if (suffix.isNotEmpty()) {
                Spacer(Modifier.width(PvotSpacing.XS))
                Text(text = suffix, fontSize = 16.sp, color = colors.textSecondaryColor)
            }
        }
    }
}

/** Composable that renders multiple wheels in a row. */
@Composable
internal fun MultiWheelEngine(
    configs: List<WheelConfig>,
    onValuesSelected: (List<Int>) -> Unit,
    modifier: Modifier = Modifier,
    colors: PvotPickerColors = PvotPickerDefaults.themeColors(),
) {
    val selectedValues =
        remember(configs) {
            configs.map { it.values.getOrElse(it.initialIndex) { 0 } }.toMutableList()
        }

    Row(horizontalArrangement = Arrangement.Center, modifier = modifier.fillMaxWidth()) {
        configs.forEachIndexed { index, config ->
            WheelEngine(
                config = config,
                onValueSelected = { value ->
                    selectedValues[index] = value
                    onValuesSelected(selectedValues.toList())
                },
                colors = colors,
            )
        }
    }
}
