// SPDX-FileCopyrightText: 2026 Saalim Quadri <danascape@gmail.com>
// SPDX-License-Identifier: Apache-2.0

package com.prauga.pvot.designsystem.platform

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable

/**
 * A [ComponentActivity] that has already opted into edge-to-edge layout.
 *
 * Extend this instead of [ComponentActivity] to get the window setup every Pvot screen expects,
 * then set content with [setPvotContent].
 */
public abstract class PvotBaseActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enablePvotEdgeToEdge()
    }

    /**
     * Sets this activity's Compose content.
     *
     * @param content The composable hierarchy, typically wrapped in PvotAppTheme
     */
    public fun setPvotContent(content: @Composable () -> Unit) {
        setContent { content() }
    }
}
